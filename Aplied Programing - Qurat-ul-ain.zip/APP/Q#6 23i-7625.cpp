#include <iostream>
#include <ctype.h>
using namespace std;
int main() {
    int A[26] = {0};
    int constrains = 0;
    int vowels = 0;
    string sentence;
    char ch;
    cout<<"\t\t\t [QURAT-UL-AIN]"<<endl;
    std::cout << "enter a sentence (press 'x to stop)";
    do {
        std::cin.get(ch);
        if (ch != 'x') {
            if (std::isalpha(ch)) {
                ch = std::tolower(ch);
                constrains++;\

                A[ch - 'a']++;

                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
                    vowels++;

            }
        }
    }while (ch != 'x');
    std::cout <<"total letters ="<<constrains<<std::endl;
    std::cout <<"total Vowels ="<<vowels<<std::endl;
    for(int i=0; i<26; i++){
        if(A[i] > 0){
            char letter='a' + i;
            std::cout<<"Total Chracter =="<<letter<<"'S"<<A[i]<<std::endl;
        }
    }
    return  0;
}
