#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void initialize(char arr[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            arr[i][j] = ' ';
        }
    }
}

void showBoard(const char arr[3][3]) {
    cout << "  0 1 2" << endl;
    for (int i = 0; i < 3; i++) {
        cout << i << " ";
        for (int j = 0; j < 3; j++) {
            cout << arr[i][j];
            if (j < 2) {
                cout << "|";
            }
        }
        cout << endl;
        if (i < 2) {
            cout << "  -+-+-" << endl;
        }
    }
}


bool ToWin(const char arr[3][3], char player) {
    for (int i = 0; i < 3; i++) {
        if (arr[i][0] == player && arr[i][1] == player && arr[i][2] == player) {
            return true;
        }
        if (arr[0][i] == player && arr[1][i] == player && arr[2][i] == player) {
            return true;
        }
    }


    if (arr[0][0] == player && arr[1][1] == player && arr[2][2] == player) {
        return true;
    }
    if (arr[0][2] == player && arr[1][1] == player && arr[2][0] == player) {
        return true;
    }

    return false;
}


bool Draw(const char arr[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (arr[i][j] == ' ') {
                return false;
            }
        }
    }
    return true;
}


void Moveofcomp(char arr[3][3]) {
    int row, col;
    do {
        row = rand() % 3;
        col = rand() % 3;
    } while (arr[row][col] != ' ');

    arr[row][col] = 'O';
}

int main() {
    char arr[3][3];
    char Player = 'X';


    srand(static_cast<unsigned>(time(nullptr)));

    initialize(arr);

    cout << "Welcome to Tic-Tac-Toe Game" << endl;
    cout << "You are 'X', and the computer is 'O'." << endl;

    while (true) {
        showBoard(arr);

        if (Player == 'X') {
            int rows, cols;
            cout << "Your turn (rows cols): ";
            cin >> rows >> cols;

            if (rows < 0 || rows >= 3 || cols < 0 || cols >= 3 || arr[rows][cols] != ' ') {
                cout << "Invalid move! opps! Try again." << endl;
                continue;
            }

            arr[rows][cols] = 'X';
        } else {
            cout << "Computer's turn..." << endl;
            Moveofcomp(arr);
        }

        if (ToWin(arr, Player)) {
            showBoard(arr);
            cout << "Player " << Player << "YOU wins! Congratulations!" << endl;
            break;
        } else if (Draw(arr)) {
            showBoard(arr);
            cout << "It's a draw! Well played!" << endl;
            break;
        }

        Player = (Player == 'X') ? 'O' : 'X';
    }

    return 0;
}
