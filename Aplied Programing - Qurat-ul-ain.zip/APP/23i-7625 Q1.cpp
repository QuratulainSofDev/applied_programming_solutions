#include<iostream>
using namespace std;
int main (){
 int a,b,c ;
 cout<<"Input the first number"<<endl;
 cin>>a;
 cout<<"Input the second number"<<endl;
 cin>>b;
 cout<<"Input the third number"<<endl;
 cin>>c;
 if(a=b=c >= 0)
 {
    cout<<"the result is true" ;
 }
 else{
     cout<<"the result is false";
 }
}