#include<iostream>
#include <iomanip>

using namespace std;
int main() {
    cout << "\t\t\t\t[Qurat ul ain Jamil]" << endl;
    cout << "_______________WELCOME TO TASTY BURGER SHOP____________" << endl;
    cout << "\t\t\t\t Here is the menu of our Shop" << endl;
    cout << "[B]... Choose your bun" << endl;
    cout << "[C]... Make it cheesy" << endl;
    cout << "[T]... Turn up the taste" << endl;
    cout << "[F]... Fresh'N it up" << endl;
    cout << "[S]... Get saucy" << endl;

    int bunoption, chezoption1, chezoption2, Ttasteoption, FreshNoption1, FreshNoption2, FreshNoption3, sauceoptionA, sauceoptionB, sauceopyionC;
    float total = 0.0;

    cout << " Select your bun(0 for skip)  " << endl;
    cout << "\t\tyou can choose one item from this cettagory" << endl;
    cin >> bunoption;
    total += 0.72;

    cout << "\t\tFOR  Make it cheesy ( 0 for skip cetagory)" << endl;
    cout << "\t\tyou can choose two item from this cettagory" << endl;
    cin >> chezoption1;
    if (chezoption1 != 0) {
        cout << "Make it cheesy (0 for skip cetagory): ";
        cin >> chezoption2;
        total += 0.5;
    }

    cout << "\t\tFOR Turn up the taste " << endl;
    cout << "\t\tyou can choose two one from this cettagory" << endl;
    cin >> Ttasteoption;
    total += 1.2;


    cout << " \t\tFOR Fresh N it up(for skip press 0) " << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> FreshNoption1;
    if (FreshNoption1 != 0) {
        cout << " Fresh N it up ( 0 to skip cetagory)"<<endl;
        cin >> FreshNoption2;
        if (FreshNoption3 != 0) {
            cout << "Fresh'N it up (0 to skip cetagory)"<<endl;
            cin >> FreshNoption3;
        }
        total += 0.2;
    }


    cout << " \t\tfor more taste Get saucy 0 for skip category)" << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> sauceoptionA;
    cout << "Enter 0 to skip or 1 for Sauce D:" << endl;
    if (sauceoptionA != 0) {
        cout << " Get saucy (Press 0 to skip category)"<<endl;
        cin >> sauceoptionB;
        if (sauceoptionB != 0) {
            cout << " Get saucy (Press 0 to skip category)"<<endl;
            cin >> sauceopyionC;
        }
        total += 0.3;
    }
    cout << "\t\tHere is the total your bill amount" << endl;
    cout << "Total Cost: $" << fixed << setprecision(2) << total << endl;

    return 0;

}