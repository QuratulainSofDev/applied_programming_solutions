#include <iostream>
using  namespace  std;
int main() {
    cout<<"\t\t\t[QURAT UL AIN]"<<endl;
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < i * 2; j++) {
            cout << "\\";
        }
        for (int k = 0; k < 22 - i * 4; k++) {
            cout << "!";
        }
        for (int j = 0; j < i * 2; j++) {
            cout << "\\";
        }
        cout << endl;
    }
    return 0;
}
