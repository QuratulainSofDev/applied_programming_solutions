#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>

using namespace std;

void playHigherLower() {
    int NO1= rand() % 20 + 1;
    cout << "First number = " << NO1 << endl;
    char userOption;
    cout << "Enter 'H' for Higher  'L' for Lower  ";
    cin >> userOption;

    int NO2 = rand() % 20 + 1;

    if ((userOption == 'H' && NO2 > NO1) || (userOption == 'L' && NO2 < NO1)) {
        cout << "You win! Second number =" << NO2 << endl;
    } else {
        cout << "You lose. Second number =" << NO2 << endl;
    }
}

void Playpaperscissorsrock () {
    int compOption = rand() % 3 + 1;
    char userOption;
    cout << "Enter 'P' for paper, 'S' for scissors, and 'R' for rock: ";
    cin >> userOption;

    if (userOption != 'P' && userOption != 'S' && userOption != 'R') {
        cout << "Invalid Option Oh! You lose" << endl;
        return;
    }

    string compOptionStr;
    if (compOption == 1) {
        compOptionStr = "paper";
    } else if ( compOption== 2) {
        compOptionStr = "scissors";
    } else {
        compOptionStr = "rock";
    }

    if ((userOption == 'p' && compOption == 2) ||
        ( userOption == 'S' && compOption == 3) ||
        ( userOption== 'R' && compOption== 1)) {
        cout << "You win" << userOption<< " beats " << compOptionStr << endl;
    } else {
        cout << "You lose Computer chose " << compOption << "." << endl;
    }
}

void guessnumbers() {
    srand(time(0));
    int randnum[3];
    int usernums[3];

    for (int i = 0; i < 3; i++) {
        randnum[i] = rand() % 10;
    }

    cout << "Random numbers =";
    for (int i = 0; i < 3; i++) {
        cout << randnum[i] << " ";
    }
    cout << endl;

    for (int i = 0; i < 3; i++) {
        while (true) {
            int usernum;
            cout << "Enter guess " << i + 1 << " (0-9): ";
            cin >> usernum;
            if (usernum >= 0 && usernum <= 9) {
                usernums [i] = usernum;
                break;
            } else {
                cout << "Invalid option Please enter  number between 0 & 9" << endl;
            }
        }
    }

    cout << "Your numbers";
    for (int i = 0; i < 3; i++) {
        cout << usernums[i] << " ";
    }
    cout << endl;

    sort(randnum, randnum + 3);
    sort(usernums, usernums + 3);

    if (randnum[0] == usernums[0] && randnum[1] == usernums[1] && randnum[2] == usernums[2]) {
        cout << "These three matching numbers in  order" << endl;
    } else if (randnum[0] == usernums[0] || randnum[1] == usernums[1] || randnum[2] == usernums[2]) {
        cout << "These three matching numbers not in order." << endl;
    } else if (randnum[0] == usernums[0] || randnum[1] == usernums[1] || randnum[2] == usernums[2]) {
        cout << "The two matching numbers" << endl;
    } else if (randnum[0] == usernums[0] || randnum[1] == usernums[1] || randnum[2] == usernums[2]) {
        cout << "One  number matched" << endl;
    } else {
        cout << "No matches" << endl;
    }
}

int main() {
    srand(time(0));

    while (true) {
        cout<<"\t\t\t[Qurat ul ain]"<<endl;
        cout << "Welcome to Guessing Games You will enjoy" << endl;
        cout << "1. Play Higher or Lower" << endl;
        cout << "2. Play Paper -> Scissors -> Rock" << endl;
        cout << "3. Guess the Numbers" << endl;
        cout << "4. Quit" << endl;

        int option;
        cout << "select your option (1 - 4): ";
        cin >> option;

        switch (option) {
            case 1:
                playHigherLower ();
                break;
            case 2:
                Playpaperscissorsrock  ();
                break;
            case 3:
                guessnumbers ();
                break;
            case 4:
                cout << "Thanks for playing " << endl;
                return 0;
            default:
                cout << "Invalid option Please select a valid option (1 - 4)." << endl;
        }
    }

    return 0;
}
