#include <iostream>
#include <vector>

using namespace std;

int main() {
    int num;
    cout<<"\t\t\t [Qurat ul ain]"<<endl;
    cout << "Enter the number of element";
    cin >> num;

    if (num <= 1) {
        cout << "There are at lest two elements for comparison" << endl;
        return 0;
    }

    vector<int> Arr(num);

    cout << "Enter the elements" << endl;
    for (int i = 0; i < num; i++) {
        cin >> Arr[i];
    }

    int maxdiff = INT_MIN  ;
    int mindiff = INT_MAX;


    for (int i = 0; i < num - 1; i++) {
        for (int j = i + 1; j < num; j++) {
            int diff = abs(Arr[i] - Arr[j]);
            maxdiff = max(maxdiff, diff);
            mindiff = min(mindiff, diff);
        }
    }

    // Find and print pairs with maximum difference
    cout << "Pairs of maximum difference (" << maxdiff << "):" << endl;
    for (int i = 0; i < num - 1; i++) {
        for (int j = i + 1; j < num; j++) {
            int diff = abs(Arr[i] - Arr[j]);
            if (diff == maxdiff) {
                cout << "(" << Arr[i] << ", " << Arr[j] << ")" << endl;
            }
        }
    }

    cout << "Pairs of  minimum difference (" << mindiff << "):" << endl;
    for (int i = 0; i < num - 1; i++) {
        for (int j = i + 1; j < num; j++) {
            int diff = abs(Arr[i] - Arr[j]);
            if (diff == mindiff) {
                cout << "(" << Arr[i] << ", " << Arr[j] << ")" << endl;
            }
        }
    }

    return 0;
}
