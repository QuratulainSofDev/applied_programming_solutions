#include<iostream>

using namespace std;
int main(){
    cout<<"\t\t\t\t[Qurat ul ain Jamil]"<<endl;
    cout<<"_______________WELCOME TO TASTY BURGER SHOP____________"<<endl;
    cout<<"\t\t\t\t Here is the menu of our Shop"<<endl;
    cout << "[B]... Choose your bun" << endl;
    cout << "[C]... Make it cheesy" << endl;
    cout << "[T]... Turn up the taste" << endl;
    cout << "[F]... Fresh'N it up" << endl;
    cout << "[S]... Get saucy" << endl;

    int bun, chez1,chez2,Ttaste,FreshN1,FreshN2,FreshN3,sauceA,sauceB,sauceC;
    cout << " Choose your bun (Enter 1 for TOASTED BRIOCHE STYLE BUN, 2 for BAKERS BUN, 3 for NO BUN(LETTUCE WRAP)): "<<endl;
    cin>>bun;

    cout << "\t\tFOR  Make it cheesy (Enter 1 for cheza , 2 for  ChezB , 0 for skip cetagory) " <<endl;
    cin >> chez1;
    cout << "Enter 0 to skip or 1 for adding more Cheese:"<<endl;
    cin >> chez2;

    cout << "\t\tFOR Turn up the taste (Enter 1 for TasteA, 2 for TasteB, 0 for skip cetagory )"  <<endl;
    cin >> Ttaste;


    cout << " \t\tFOR Fresh'N it up (Enter 1 for FreshNA, 2 for FreshNB, 3 for FreshNC, 0 for skip cetagory)"<<endl;
    cin >> FreshN1;
    cout << "Enter 0 to skip or 1 for adding Fresh D:" <<endl;
    cin >> FreshN2;
    cout << "Enter 0 to skip or 1 for adding Fresh E:"<<endl;
    cin >> FreshN3;


    cout << " \t\tfor more taste Get saucy (Enter 1 for SauceA, 2 for SauceB, 3 for SauceC, 0 for skip cetagory)"<<endl;
    cin >> sauceA;
    cout << "Enter 0 to skip or 1 for Sauce D:"<<endl;
    cin >> sauceB;
    cout << "Enter 0 to skip or 1 for Sauce E:"<< endl;
    cin >> sauceC;

    double total = 0.0;

    switch (bun) {
        case 1:
            total += 0.72;
            break;
        case 2:
            total += 0.72;
            break;
        case 3:
            total += 0.72;
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }
    switch (chez1) {
        case 1:
            total += 0.5;
            break;
        case 2:
            total += 0.5;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }

    switch (chez2) {
        case 1:
            total += 0.5;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }

    switch (Ttaste) {
        case 1:
            total += 1.2;
            break;
        case 2:
            total += 1.2;
            break;
        case 0:
            cout << "Invalid input" << endl;
            return 0;
    }


    switch (FreshN1) {
        case 1:
            total += 0.2;
            break;
        case 2:
            total += 0.2;
            break;
        case 3:
            total += 0.2;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input for fresh1" << endl;
            return 0;
    }

    switch (FreshN2) {
        case 1:
            total += 0.2;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }

    switch (FreshN3) {
        case 1:
            total += 0.2;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }


    switch (sauceA) {
        case 1:
            total += 0.3;
            break;
        case 2:
            total += 0.3;
            break;
        case 3:
            total += 0.3;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }

    switch (sauceB) {
        case 1:
            total += 0.3;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input " << endl;
            return 0;
    }

    switch (sauceC) {
        case 1:
            total += 0.3;
            break;
        case 0:
            break;
        default:
            cout << "Invalid input" << endl;
            return 0;
    }

    cout << "Total cost= $" << total << endl;
    return 0;
}
