#include <iostream>
using namespace std;

void arrangeabc(char Arr[], int len) {
    int asCount = 0;
    int bsCount = 0;
    int csCount = 0;


    for (int i = 0; i < len; i++) {
        if (Arr[i] == 'a') {
            asCount++;
        } else if (Arr[i] == 'b') {
            bsCount++;
        } else if (Arr[i] == 'c') {
            csCount++;
        }
    }
    int index = 0;

    for (int i = 0; i < asCount; i++) {
        Arr[index++] = 'a';
    }

    for (int i = 0; i < bsCount; i++) {
        Arr[index++] = 'b';
    }

    for (int i = 0; i < csCount; i++) {
        Arr[index++] = 'c';
    }
}

int main() {
    cout<<"\t\t\t[Qurat ul ain]"<<endl;
    char Arr[] = {'a', 'c', 'b', 'b', 'c', 'b', 'a', 'c', 'a', 'b','a','b','c'};
    int len = sizeof(Arr);


    arrangeabc(Arr, len);


    for (int i = 0; i < len; i++) {

        cout << Arr[i] << " ";
    }

    return 0;
}
