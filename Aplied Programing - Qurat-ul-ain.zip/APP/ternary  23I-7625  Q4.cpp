#include<iostream>
#include <iomanip>

using namespace std;
int main() {
    cout << "\t\t\t\t[Qurat ul ain Jamil]" << endl;
    cout << "_______________WELCOME TO TASTY BURGER SHOP____________" << endl;
    cout << "\t\t\t\t Here is the menu of our Shop" << endl;
    cout << "[B]... Choose your bun" << endl;
    cout << "[C]... Make it cheesy" << endl;
    cout << "[T]... Turn up the taste" << endl;
    cout << "[F]... Fresh'N it up" << endl;
    cout << "[S]... Get saucy" << endl;

    int bunoption, chezoption1, chezoption2, Ttasteoption, FreshNoption1, FreshNoption2, FreshNoption3, sauceoptionA, sauceoptionB, sauceopyionC;
    float total = 0.0;

    cout << " Select your bun(0 for skip)  " << endl;
    cout << "\t\tyou can choose one item from this cettagory" << endl;
    cin >> bunoption;
    total += (bunoption!= 0) ? 0.72 : 0.0;

    cout << "\t\tFOR  Make it cheesy ( 0 for skip cetagory)" << endl;
    cout << "\t\tyou can choose two item from this cettagory" << endl;
    cin >> chezoption1;
    total += (chezoption1 != 0) ? 0.5 : 0.0;
    if (chezoption1 != 0) {
        cout << "Make it cheesy (0 for skip cetagory): ";
        cin >> chezoption2;
        total += (chezoption1 != 0) ? 0.5 : 0.0;
    }

    cout << "\t\tFOR Turn up the taste " << endl;
    cout << "\t\tyou can choose two one from this cettagory" << endl;
    cin >> Ttasteoption;
    total += (Ttasteoption != 0) ? 1.2 : 0.0;;


    cout << " \t\tFOR Fresh N it up(for skip press 0) " << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> FreshNoption1;
    total += (FreshNoption1 != 0) ? 0.2 : 0.0;

    if (FreshNoption2 != 0) {
        cout << " Fresh'N it up (Press 0 to skip): ";
        cin >> FreshNoption3;
        total += (FreshNoption3 != 0) ? 0.2 : 0.0;
    }

    cout << " \t\tfor more taste Get saucy 0 for skip category)" << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> sauceoptionA;
    total += (sauceoptionA != 0) ? 0.3 : 0.0;

    cout << "Enter 0 to skip or 1 for Sauce D:" << endl;

    if (sauceoptionA != 0) {
        cout << " Get saucy (Press 0 to skip category)"<<endl;
        cin >> sauceoptionB;
        total += (sauceoptionB != 0) ? 0.3 : 0.0;

        if (sauceoptionB != 0) {
            cout << " Get saucy (Press 0 to skip category)"<<endl;
            cin >> sauceopyionC;
        }
        total += (sauceopyionC != 0) ? 0.3 : 0.0;
    }
    cout << "\t\tHere is the total your bill amount" << endl;
    cout << "Total Cost: $" << fixed << setprecision(2) << total << endl;

    return 0;

}#include<iostream>
#include <iomanip>

using namespace std;
int main() {
    cout << "\t\t\t\t[Qurat ul ain Jamil]" << endl;
    cout << "_______________WELCOME TO TASTY BURGER SHOP____________" << endl;
    cout << "\t\t\t\t Here is the menu of our Shop" << endl;
    cout << "[B]... Choose your bun" << endl;
    cout << "[C]... Make it cheesy" << endl;
    cout << "[T]... Turn up the taste" << endl;
    cout << "[F]... Fresh'N it up" << endl;
    cout << "[S]... Get saucy" << endl;

    int bunoption, chezoption1, chezoption2, Ttasteoption, FreshNoption1, FreshNoption2, FreshNoption3, sauceoptionA, sauceoptionB, sauceopyionC;
    float total = 0.0;

    cout << " Select your bun(0 for skip)  " << endl;
    cout << "\t\tyou can choose one item from this cettagory" << endl;
    cin >> bunoption;
    total += (bunoption!= 0) ? 0.72 : 0.0;

    cout << "\t\tFOR  Make it cheesy ( 0 for skip cetagory)" << endl;
    cout << "\t\tyou can choose two item from this cettagory" << endl;
    cin >> chezoption1;
    total += (chezoption1 != 0) ? 0.5 : 0.0;
    if (chezoption1 != 0) {
        cout << "Make it cheesy (0 for skip cetagory): ";
        cin >> chezoption2;
        total += (chezoption1 != 0) ? 0.5 : 0.0;
    }

    cout << "\t\tFOR Turn up the taste " << endl;
    cout << "\t\tyou can choose two one from this cettagory" << endl;
    cin >> Ttasteoption;
    total += (Ttasteoption != 0) ? 1.2 : 0.0;;


    cout << " \t\tFOR Fresh N it up(for skip press 0) " << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> FreshNoption1;
    total += (FreshNoption1 != 0) ? 0.2 : 0.0;

    if (FreshNoption2 != 0) {
        cout << " Fresh'N it up (Press 0 to skip): ";
        cin >> FreshNoption3;
        total += (FreshNoption3 != 0) ? 0.2 : 0.0;
    }

    cout << " \t\tfor more taste Get saucy 0 for skip category)" << endl;
    cout << "\t\tyou can choose three item from this cettagory" << endl;
    cin >> sauceoptionA;
    total += (sauceoptionA != 0) ? 0.3 : 0.0;

    cout << "Enter 0 to skip or 1 for Sauce D:" << endl;

    if (sauceoptionA != 0) {
        cout << " Get saucy (Press 0 to skip category)"<<endl;
        cin >> sauceoptionB;
        total += (sauceoptionB != 0) ? 0.3 : 0.0;

        if (sauceoptionB != 0) {
            cout << " Get saucy (Press 0 to skip category)"<<endl;
            cin >> sauceopyionC;
        }
        total += (sauceopyionC != 0) ? 0.3 : 0.0;
    }
    cout << "\t\tHere is the total your bill amount" << endl;
    cout << "Total Cost: $" << fixed << setprecision(2) << total << endl;

    return 0;

}