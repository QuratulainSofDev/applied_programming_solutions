#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int Gallon;
    double bill;

    float Totalbill;
    cout<<"the number of gallon is used"<<endl;
    cin>>Gallon;
    if(Gallon<100){
        bill=( 0.45/Gallon);
         Totalbill = round(bill * 100.0) / 100.0;
        cout<<"total bill ="<<Totalbill;
    }
    if (Gallon<250){
        bill=(0.85/Gallon);
        Totalbill = round(bill * 100.0) / 100.0;
        cout<<"total bill ="<<Totalbill;
    }
    else if(Gallon<500) {
        bill=(1.45/Gallon);
        Totalbill = round(bill * 100.0) / 100.0;
        cout<<"total bill ="<<Totalbill;
 }
    if(Gallon>600){
        bill=((2.60/Gallon)+14);
        Totalbill = round(bill * 100.0) / 100.0;
        cout<<"total bill ="<<Totalbill;
    }


}
