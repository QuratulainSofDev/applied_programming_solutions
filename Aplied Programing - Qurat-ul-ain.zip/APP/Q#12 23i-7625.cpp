#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;


int calcuLen(const char *str) {
    return strlen(str);
}

int countword(const char *str) {
    int wordcount = 0;
    bool isword = false;

    for (int i = 0; str[i] != '\0'; i++) {
        if (isalpha(str[i])) {
            if (!isword) {
                wordcount++;
                isword = true;
            }
        } else {
            isword = false;
        }
    }

    return wordcount;
}


bool isPalindrome(const char *str) {
    int left = 0;
    int right = strlen(str) - 1;

    while (left < right) {
        if (str[left] != str[right]) {
            return false;
        }
        left++;
        right--;
    }

    return true;
}


int wordfind(const char *str, const char *words) {
    const char *position = strstr(str, words);
    if (position == nullptr) {
        return -1; // Word not found
    } else {
        return position - str;
    }
}


void Lowercase(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = tolower(str[i]);
    }
}


void Uppercase(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = toupper(str[i]);
    }
}

int main() {
    char input[100];
    char choice;
    char wordToFind[100];

    cout << "Enter a string ";
    cin.getline(input, sizeof(input));

    do {
        cout << "\t\t\t[QURAT-UL-AIN]"<<endl;
        cout << "\tHere is the Menu:"<<endl;
        cout << "A. For calculate the length of the string"<<endl;
        cout << "B. For count the number of words in the string"<<endl;
        cout << "C.For Checking  the string is a palindrome"<<endl;
        cout << "D.For finding  a word in the string"<<endl;
        cout << "E.To converting the string into lowercase"<<endl;
        cout << "F.To converting the string into uppercase"<<endl;
        cout << "G. Exit"<<endl;
        cout << "Enter your Choice ";
        cin >> choice;
        cin.ignore(); // Consume the newline character

        switch (choice) {
            case '1': {
                cout << "Length of the string =" << calcuLen(input) << endl;
                break;
            }
            case '2':{
                cout << "Number of words in the string: " << countword(input) << endl;
                break;
            }
            case '3':{
                if (isPalindrome(input)) {
                    cout << "The string is a palindrome" << endl;
                } else {
                    cout << "The string is not a palindrome" << endl;
                }
                break;
            }
            case '4':{
                cout << "Enter a word to find: ";
                cin.getline(wordToFind, sizeof(wordToFind));
                int startPos = wordfind(input, wordToFind);
                if (startPos != -1) {
                    cout << "Word found at position: " << startPos << endl;
                } else {
                    cout << "Word not found in the string." << endl;
                }
                break;
            }
            case '5':{
                Lowercase(input);
                cout << "String in lowercase" << input << endl;
                break;
            }
            case '6':{
                Uppercase(input);
                cout << "String in uppercase" << input << endl;
                break;
            }
            case '7':{
                cout << "Goodbye!" << endl;
                break;
            }
            default:{
                cout << "Invalid selection! Please try again." << endl;
            }
        }
    } while (choice != '7');

    return 0;
}
