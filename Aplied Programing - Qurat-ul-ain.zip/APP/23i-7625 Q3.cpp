#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;


char NumberColor(int num) {
    int col = num % 6;
    if(col == 0)
        return 'Red';
    else  if(col == 1)
        return 'Green';
    else  if(col == 2)
        return 'White';
    else  if(col == 3)
        return 'Black';
    else if(col == 4)
        return 'Blue';
    else if(col == 5)
        return 'Yelow';
    else return 'Red';
}

int main() {

    vector<vector<int>> grid(6, vector<int>(6));
    vector<vector<char>> colors(6, vector<char>(6));


    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j < 6; ++j) {
            grid[i][j] = rand() % 36 + 1;
            colors[i][j] = NumberColor(grid[i][j]);
        }
    }

    int select = 1;
    int victories = 0;
    int warnings = 0;
    vector<pair<int, int>> previousVictories;

    while (select <= 5) {
        int num1, num2;
        bool InputValid = false;

        cout << "Round " << select << endl;

        while (!InputValid) {
            cout << "Enter two numbers within the grid range: ";
            cin >> num1 >> num2;

            if (num1 >= 1 && num1 <= 36 && num2 >= 1 && num2 <= 36) {
                InputValid = true;
            } else {
                cout << "Invalid input. Numbers must be within the grid range 1-36." << endl;
            }
        }

        if (find(previousVictories.begin(), previousVictories.end(), make_pair(num1, num2)) != previousVictories.end() ||
            find(previousVictories.begin(), previousVictories.end(), make_pair(num2, num1)) != previousVictories.end()) {
            warnings++;
            if (warnings >= 3) {
                cout << "WARNING 3 ***END OF PROGRAM***" << endl;
                return 0;
            }
            cout << "WARNING " << warnings << endl;
        } else {
            char col1 = ' ';
            char col2 = ' ';

            for (int i = 0; i < 6; ++i) {
                for (int j = 0; j < 6; ++j) {
                    if (grid[i][j] == num1) {
                        col1 = colors[i][j];
                    }
                    if (grid[i][j] == num2) {
                        col2 = colors[i][j];
                    }
                }
            }

            if (col1 == col2) {
                cout << "Round " << select << " Victory!" << endl;
                victories++;
                previousVictories.push_back(make_pair(num1, num2));
            } else {
                cout << "Round " << select << " Not a match." << endl;
            }
        }

        select++;
    }

    if (victories >= 3) {
        cout << "Congratulations! You win!" << endl;
    } else {
        cout << "Sorry, you did not win." << endl;
    }

    return 0;
}
