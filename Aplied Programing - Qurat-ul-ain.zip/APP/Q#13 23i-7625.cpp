#include <iostream>
using namespace std;

//  count occurrences  x in A[]
int Count(int A[], int n, int x) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (A[i] == x) {
            count++;
        }
    }
    return count;
}

void Part(int A[], int num) {
    if (num <= 1) {
        return;
    }

    int vot = A[0];
    int L = 1;
    int R = num - 1;

    while (L <= R) {
        while (L <= R && A[L] <= vot) {
            L++;
        }
        while (L <= R && A[R] > vot) {
            R--;
        }
        if (L < R) {
            swap(A[L], A[R]);
        }
    }

    swap(A[0], A[R]);
}


void Frequencies(int A[], int num) {
    cout << "Element frequencies:" << endl;
    for (int i = 0; i < num; i++) {
        if (A[i] == -1) {
            continue;
        }
        int count = 1;
        for (int j = i + 1; j < num; j++) {
            if (A[i] == A[j]) {
                count++;
                A[j] = -1;
            }
        }
        cout << A[i] << ": " << count << " times" << endl;
    }
}


void replace(int A[], int size) {
    for (int i = 0; i < size; i++) {
        int next1 = (i + 1) % size;
        int next2 = (i + 2) % size;
        A[i] = A[next1] + A[next2];
    }
}


int Find(int A[], int size, int x) {
    for (int i = 0; i < size; i++) {
        if (A[i] == x) {
            return i;
        }
    }
    return -1;
}

int main() {
    int size;
    cout << "Enter the size of the array";
    cin >> size;
    int A[100];
    cout << "Enter the elements of the array";
    for (int i = 0; i < size; i++) {
        cin >> A[i];
    }

    int option;
    do {
        cout<<"\t\t [QURAT UL AIN]"<<endl;
        cout << "\nWelcome Here is the Menu"<<endl;
        cout << "1.  occurrences of a number"<<endl;
        cout << "2. Partition the array"<<endl;
        cout << "3. Calculate element frequencies"<<endl;
        cout << "4. Circular replacement"<<endl;
        cout << "5. Search for an element"<<endl;
        cout << "6. Exit"<<endl;
        cout << "Enter your choice: "<<endl;
        cin >> option;

        switch (option) {
            case 1: {
                int x;
                cout << "Enter the number to count: ";
                cin >> x;
                int count = Count(A, size, x);
                cout << x << " occurs " << count << " times in the array." << endl;
                break;
            }
            case 2: {
                Part(A, size);
                cout << "Array partitioned." << endl;
                break;
            }
            case 3: {
                Frequencies(A, size);
                break;
            }
            case 4: {
                replace(A, size);
                cout << "Array elements replaced in a circular manner." << endl;
                break;
            }
            case 5: {
                int x;
                cout << "Enter the element to search for: ";
                cin >> x;
                int index = Find(A, size, x);
                if (index != -1) {
                    cout << x << " found " << index << "." << endl;
                } else {
                    cout << x << " element  not found in the array." << endl;
                }
                break;
            }
            case 6: {
                cout << "Program exit" << endl;
                break;
            }
            default: {
                cout << "Invalid Option oh!   try again." << endl;
                break;
            }
        }
    } while (option != 6);

    return 0;
}
